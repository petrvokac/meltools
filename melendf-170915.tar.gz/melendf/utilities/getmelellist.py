#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''example use of the melendfmod package'''

import melendfmod.elements as elements
cel=elements.elements() 
cel.fPrintMELCORElements()


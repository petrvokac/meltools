test2 repeated using melendf.py 

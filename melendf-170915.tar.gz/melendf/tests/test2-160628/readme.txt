simplified test on decay calculation
endf.py and endf.pickle as of Jul 28, 2016
